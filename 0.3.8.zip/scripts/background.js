'use strict';

console.log('Event Page for Browser Action');
