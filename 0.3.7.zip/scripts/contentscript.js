'use strict';

console.log('Content script');
